import re
import math
from collections import Counter
from datetime import date, timedelta


# ===========================================================================
# 1. SENTIMENT ANALYSIS  (lexicon + negation handling)
# ===========================================================================
_POSITIVE = {
    "amazing", "excellent", "great", "good", "wonderful", "fantastic", "perfect",
    "love", "loved", "lovely", "clean", "comfortable", "friendly", "delicious",
    "beautiful", "cozy", "helpful", "recommend", "best", "awesome", "superb",
    "spotless", "stunning", "exceptional", "outstanding", "pleasant", "fresh",
    "tasty", "polite", "spacious", "quiet", "relaxing", "value", "worth", "happy",
}
_NEGATIVE = {
    "bad", "terrible", "awful", "horrible", "dirty", "rude", "slow", "cold",
    "expensive", "noisy", "disappointing", "disappointed", "poor", "worst",
    "broken", "smell", "smelly", "uncomfortable", "overpriced", "crowded",
    "unfriendly", "stale", "bland", "tiny", "cramped", "filthy", "avoid",
    "waited", "wait", "never", "problem", "issue", "leak", "mold", "bug",
}
_NEGATORS = {"not", "no", "never", "without", "hardly", "barely", "neither"}


def analyze_sentiment(text):
    """Return (label, score) where score is in [-1, 1]."""
    if not text:
        return "neutral", 0.0
    tokens = re.findall(r"[a-z']+", text.lower())
    score = 0
    negate = False
    for tok in tokens:
        if tok in _NEGATORS:
            negate = True
            continue
        weight = 0
        if tok in _POSITIVE:
            weight = 1
        elif tok in _NEGATIVE:
            weight = -1
        if negate:
            weight *= -1
            negate = False
        score += weight
    # Normalise by a soft length factor
    norm = score / math.sqrt(max(len(tokens), 1))
    norm = max(-1.0, min(1.0, norm))
    if norm > 0.15:
        label = "positive"
    elif norm < -0.15:
        label = "negative"
    else:
        label = "neutral"
    return label, round(norm, 3)


# ===========================================================================
# 2. CONTENT-BASED RECOMMENDER
# ===========================================================================
def _unit_feature_vector(unit):
    """Build a simple feature dictionary describing a unit."""
    feats = Counter()
    feats[f"type:{unit.type}"] += 3
    if unit.city:
        feats[f"city:{unit.city.lower()}"] += 2
    if unit.cuisine:
        for word in re.findall(r"[a-z]+", unit.cuisine.lower()):
            feats[f"cuisine:{word}"] += 2
    for am in unit.amenities:
        feats[f"amenity:{am.name.lower()}"] += 1
    # price bucket
    bucket = "budget" if unit.base_price < 60 else "mid" if unit.base_price < 150 else "luxury"
    feats[f"price:{bucket}"] += 1
    return feats


def _user_profile_vector(user):
    """Aggregate a user's taste from preferences, reservations and reviews."""
    profile = Counter()
    for tag in (user.preferences or "").split(","):
        tag = tag.strip().lower()
        if tag:
            profile[f"amenity:{tag}"] += 2
            profile[f"cuisine:{tag}"] += 1
            profile[f"type:{tag}"] += 1
    # Learn from booking history
    for res in user.reservations:
        if res.unit:
            for feat, w in _unit_feature_vector(res.unit).items():
                profile[feat] += w * 0.5
    # Boost things they rated highly
    for rev in user.reviews:
        if rev.unit and rev.rating >= 4:
            for feat, w in _unit_feature_vector(rev.unit).items():
                profile[feat] += w * 0.4
    return profile


def _cosine(a, b):
    keys = set(a) | set(b)
    dot = sum(a.get(k, 0) * b.get(k, 0) for k in keys)
    na = math.sqrt(sum(v * v for v in a.values()))
    nb = math.sqrt(sum(v * v for v in b.values()))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


def recommend_units(user, all_units, limit=4):
    """Return a ranked list of (unit, score, reason) for the given user."""
    approved = [u for u in all_units if u.status == "approved"]
    if not approved:
        return []

    booked_ids = {r.unit_id for r in user.reservations} if user else set()
    profile = _user_profile_vector(user) if user else Counter()

    scored = []
    for unit in approved:
        if unit.id in booked_ids:
            continue
        vec = _unit_feature_vector(unit)
        sim = _cosine(profile, vec) if profile else 0.0
        # Blend similarity with popularity & quality signals
        quality = unit.avg_rating / 5.0
        popularity = min(unit.review_count / 20.0, 1.0)
        featured = 0.15 if unit.is_featured else 0.0
        score = 0.55 * sim + 0.30 * quality + 0.10 * popularity + featured
        reason = _explain_recommendation(profile, vec, unit)
        scored.append((unit, round(score, 3), reason))

    scored.sort(key=lambda x: x[1], reverse=True)
    return scored[:limit]


def _explain_recommendation(profile, vec, unit):
    """Produce a short human-readable reason for a recommendation."""
    if not profile:
        if unit.avg_rating >= 4.5:
            return "Top-rated by our community"
        if unit.is_featured:
            return "Featured pick of the week"
        return "Popular near you"
    overlap = {k: profile[k] for k in vec if k in profile and profile[k] > 0}
    if not overlap:
        return "Highly rated and trending"
    best = max(overlap, key=overlap.get)
    kind, _, value = best.partition(":")
    pretty = {
        "amenity": f"matches your love of {value}",
        "cuisine": f"serves {value} cuisine you enjoy",
        "city": f"in {value.title()}, where you often book",
        "type": f"a {value} like ones you've enjoyed",
        "price": f"fits your usual {value} budget",
    }.get(kind, "matches your taste")
    return f"Recommended because it {pretty}"


# ===========================================================================
# 3. DEMAND FORECASTING  (seasonality + trend heuristic)
# ===========================================================================
_WEEKDAY_FACTOR = [0.85, 0.80, 0.82, 0.90, 1.20, 1.35, 1.10]  # Mon..Sun
_MONTH_FACTOR = [0.7, 0.7, 0.8, 0.9, 1.0, 1.15, 1.3, 1.3, 1.05, 0.9, 0.8, 1.1]


def forecast_demand(unit, days=14):
    """Forecast occupancy % for the next `days` days based on existing bookings."""
    resources = max(len([r for r in unit.resources if r.is_active]), 1)
    today = date.today()

    # Historical baseline: how booked the last 30 days were
    recent = [r for r in unit.reservations if r.status in ("confirmed", "completed")]
    base_load = min(len(recent) / (resources * 4.0), 1.0) if recent else 0.35

    forecast = []
    for i in range(days):
        d = today + timedelta(days=i)
        booked = sum(
            1 for r in unit.reservations
            if r.status in ("pending", "confirmed")
            and r.start_date <= d <= (r.end_date or r.start_date)
        )
        seasonal = _WEEKDAY_FACTOR[d.weekday()] * _MONTH_FACTOR[d.month - 1]
        predicted = min((base_load * seasonal) + (booked / resources), 1.0)
        forecast.append({
            "date": d.isoformat(),
            "label": d.strftime("%a %d"),
            "occupancy": round(predicted * 100),
            "booked": booked,
            "capacity": resources,
        })
    return forecast


def suggest_price(unit):
    """Dynamic-pricing advisor: suggest a price band from demand & quality."""
    fc = forecast_demand(unit, days=7)
    avg_occ = sum(f["occupancy"] for f in fc) / len(fc) / 100.0
    quality_mult = 0.9 + (unit.avg_rating / 5.0) * 0.3  # 0.9 .. 1.2
    demand_mult = 0.85 + avg_occ * 0.45                  # 0.85 .. 1.30
    base = unit.base_price or 50
    low = round(base * quality_mult * 0.92)
    optimal = round(base * quality_mult * demand_mult)
    high = round(base * quality_mult * demand_mult * 1.12)
    verdict = (
        "Raise prices — strong demand ahead" if avg_occ > 0.7 else
        "Hold steady — balanced demand" if avg_occ > 0.4 else
        "Consider a promotion — soft demand"
    )
    return {
        "current": round(base),
        "low": low,
        "optimal": optimal,
        "high": high,
        "avg_occupancy": round(avg_occ * 100),
        "verdict": verdict,
    }


# ===========================================================================
# 4. SMART CONCIERGE  (intent parsing + optional LLM)
# ===========================================================================
_CITY_HINTS = ["tirana", "durres", "vlore", "saranda", "shkoder", "berat",
               "london", "paris", "rome", "milan", "athens", "berlin", "barcelona"]


def parse_query(text):
    """Extract structured filters from a free-text search/chat message."""
    t = (text or "").lower()
    intent = {
        "type": None, "city": None, "guests": None,
        "max_price": None, "amenities": [], "cuisine": None,
    }
    if any(w in t for w in ["hotel", "stay", "room", "sleep", "night", "accommodation"]):
        intent["type"] = "hotel"
    if any(w in t for w in ["restaurant", "dinner", "lunch", "eat", "table", "dine", "food"]):
        intent["type"] = "restaurant"
    for city in _CITY_HINTS:
        if city in t:
            intent["city"] = city
            break
    m = re.search(r"(\d+)\s*(?:people|guests|persons|pax|of us)", t)
    if m:
        intent["guests"] = int(m.group(1))
    m = re.search(r"(?:under|below|less than|max|up to)\s*\$?(\d+)", t)
    if m:
        intent["max_price"] = int(m.group(1))
    for am in ["wifi", "pool", "parking", "spa", "gym", "breakfast", "pet", "balcony", "terrace"]:
        if am in t:
            intent["amenities"].append(am)
    for cz in ["italian", "japanese", "sushi", "seafood", "vegan", "mediterranean",
               "indian", "mexican", "french", "greek", "albanian", "bbq", "pizza"]:
        if cz in t:
            intent["cuisine"] = cz
            break
    return intent


def search_units(intent, all_units, limit=6):
    """Score units against a parsed intent."""
    results = []
    for u in all_units:
        if u.status != "approved":
            continue
        score = 1.0
        if intent["type"] and u.type != intent["type"]:
            continue
        if intent["city"]:
            if u.city and intent["city"] in u.city.lower():
                score += 2.0
            else:
                continue
        if intent["max_price"]:
            if u.base_price <= intent["max_price"]:
                score += 1.0
            else:
                score -= 1.0
        if intent["guests"]:
            if u.capacity >= intent["guests"] or any(r.capacity >= intent["guests"] for r in u.resources):
                score += 1.0
        if intent["cuisine"] and u.cuisine and intent["cuisine"] in u.cuisine.lower():
            score += 1.5
        unit_ams = {a.name.lower() for a in u.amenities}
        for am in intent["amenities"]:
            if any(am in ua for ua in unit_ams):
                score += 0.8
        score += u.avg_rating * 0.2
        results.append((u, round(score, 2)))
    results.sort(key=lambda x: x[1], reverse=True)
    return [u for u, _ in results[:limit]]


def concierge_reply(message, all_units, api_key=""):
    """
    Generate a concierge response. Returns dict:
      { "text": str, "units": [Unit, ...] }
    Uses the LLM if api_key is present, otherwise the offline engine.
    """
    intent = parse_query(message)
    matches = search_units(intent, all_units, limit=4)

    if api_key:
        llm_text = _llm_concierge(message, matches, api_key)
        if llm_text:
            return {"text": llm_text, "units": matches}

    # ---- Offline natural-language response ----
    parts = []
    if not matches:
        return {
            "text": ("I couldn't find an exact match. Try telling me the city, "
                     "whether you want a hotel or a restaurant, your budget, and "
                     "how many guests — e.g. \"Italian restaurant in Tirana for 4 "
                     "under $40\"."),
            "units": [],
        }
    descriptor = []
    if intent["type"]:
        descriptor.append(intent["type"] + "s")
    if intent["city"]:
        descriptor.append("in " + intent["city"].title())
    if intent["max_price"]:
        descriptor.append(f"under ${intent['max_price']}")
    head = "Here are some great " + (" ".join(descriptor) if descriptor else "options") + " I found for you:"
    parts.append(head)
    for u in matches:
        line = f"• {u.name} — {u.city}, {u.avg_rating}★"
        if u.type == "restaurant" and u.cuisine:
            line += f", {u.cuisine}"
        line += f" (from ${round(u.base_price)}{u.price_label})"
        parts.append(line)
    parts.append("Tap any card below to view details and book instantly. Anything else you'd like to refine?")
    return {"text": "\n".join(parts), "units": matches}


def _llm_concierge(message, matches, api_key):
    """Optional Anthropic-powered reply. Returns None on any failure."""
    try:
        import json
        import urllib.request

        catalogue = "\n".join(
            f"- {u.name} | {u.type} | {u.city} | {u.avg_rating}star | "
            f"${round(u.base_price)}{u.price_label} | {u.cuisine or ''}"
            for u in matches
        ) or "(no direct matches in catalogue)"

        system = (
            "You are the friendly concierge for StayPlate, a hotel & restaurant "
            "reservation platform. Be concise, warm and helpful. Only recommend "
            "establishments from the provided catalogue. Never invent places."
        )
        user_block = f"Catalogue:\n{catalogue}\n\nGuest message: {message}"

        payload = json.dumps({
            "model": "claude-sonnet-4-20250514",
            "max_tokens": 400,
            "system": system,
            "messages": [{"role": "user", "content": user_block}],
        }).encode()

        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=payload,
            headers={
                "content-type": "application/json",
                "x-api-key": api_key,
                "anthropic-version": "2023-06-01",
            },
        )
        with urllib.request.urlopen(req, timeout=20) as resp:
            data = json.loads(resp.read())
        return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
    except Exception:
        return None
