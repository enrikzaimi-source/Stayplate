"""SQLAlchemy models for the StayPlate reservation platform."""
from datetime import datetime, date
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from extensions import db


# ---------------------------------------------------------------------------
# Association table: units <-> amenities (many-to-many)
# ---------------------------------------------------------------------------
unit_amenities = db.Table(
    "unit_amenities",
    db.Column("unit_id", db.Integer, db.ForeignKey("unit.id"), primary_key=True),
    db.Column("amenity_id", db.Integer, db.ForeignKey("amenity.id"), primary_key=True),
)


class User(UserMixin, db.Model):
    """Platform user. Role is one of: 'user', 'manager', 'admin'."""

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    phone = db.Column(db.String(30))
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="user")
    avatar = db.Column(db.String(255))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Soft preference vector used by the AI recommender (comma-separated tags)
    preferences = db.Column(db.String(255), default="")

    # Relationships
    units = db.relationship("Unit", backref="manager", lazy=True, cascade="all, delete-orphan")
    reservations = db.relationship("Reservation", backref="customer", lazy=True, cascade="all, delete-orphan")
    reviews = db.relationship("Review", backref="author", lazy=True, cascade="all, delete-orphan")
    favorites = db.relationship("Favorite", backref="user", lazy=True, cascade="all, delete-orphan")
    notifications = db.relationship("Notification", backref="user", lazy=True, cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def is_admin(self):
        return self.role == "admin"

    @property
    def is_manager(self):
        return self.role == "manager"

    @property
    def initials(self):
        parts = self.full_name.split()
        if len(parts) >= 2:
            return (parts[0][0] + parts[-1][0]).upper()
        return self.full_name[:2].upper()

    def unread_notifications(self):
        return [n for n in self.notifications if not n.is_read]

    def __repr__(self):
        return f"<User {self.email} ({self.role})>"


class Amenity(db.Model):
    """A feature an establishment can offer (WiFi, Pool, Parking...)."""

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(60), unique=True, nullable=False)
    icon = db.Column(db.String(40), default="star")  # lucide icon name

    def __repr__(self):
        return f"<Amenity {self.name}>"


class Unit(db.Model):
    """A bookable establishment: a hotel or a restaurant."""

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(140), nullable=False)
    type = db.Column(db.String(20), nullable=False, default="hotel")  # 'hotel' | 'restaurant'
    description = db.Column(db.Text)
    city = db.Column(db.String(80), index=True)
    address = db.Column(db.String(200))
    image = db.Column(db.String(255), default="placeholder.jpg")
    base_price = db.Column(db.Float, default=0.0)  # per night (hotel) / avg per person (restaurant)
    capacity = db.Column(db.Integer, default=2)    # default resource capacity
    cuisine = db.Column(db.String(80))             # restaurants only
    star_rating = db.Column(db.Integer, default=3) # hotels only (1-5 official stars)
    status = db.Column(db.String(20), default="pending")  # pending | approved | rejected
    is_featured = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    manager_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)

    resources = db.relationship("Resource", backref="unit", lazy=True, cascade="all, delete-orphan")
    reservations = db.relationship("Reservation", backref="unit", lazy=True, cascade="all, delete-orphan")
    reviews = db.relationship("Review", backref="unit", lazy=True, cascade="all, delete-orphan")
    favorites = db.relationship("Favorite", backref="unit", lazy=True, cascade="all, delete-orphan")
    amenities = db.relationship("Amenity", secondary=unit_amenities, backref="units")

    @property
    def avg_rating(self):
        if not self.reviews:
            return 0.0
        return round(sum(r.rating for r in self.reviews) / len(self.reviews), 1)

    @property
    def review_count(self):
        return len(self.reviews)

    @property
    def unit_label(self):
        return "Room" if self.type == "hotel" else "Table"

    @property
    def price_label(self):
        return "/ night" if self.type == "hotel" else "/ person"

    def __repr__(self):
        return f"<Unit {self.name} ({self.type})>"


class Resource(db.Model):
    """A bookable resource inside a unit: a hotel room or a restaurant table."""

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)  # "Deluxe Room 101" / "Window Table 5"
    capacity = db.Column(db.Integer, default=2)
    price = db.Column(db.Float, default=0.0)
    description = db.Column(db.String(255))
    is_active = db.Column(db.Boolean, default=True)

    unit_id = db.Column(db.Integer, db.ForeignKey("unit.id"), nullable=False)
    reservations = db.relationship("Reservation", backref="resource", lazy=True)

    def __repr__(self):
        return f"<Resource {self.name}>"


class Reservation(db.Model):
    """A booking made by a customer for a resource within a unit."""

    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(12), unique=True, index=True)

    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    unit_id = db.Column(db.Integer, db.ForeignKey("unit.id"), nullable=False)
    resource_id = db.Column(db.Integer, db.ForeignKey("resource.id"), nullable=False)

    # Hotels use start/end date. Restaurants use start_date + a time slot.
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date)          # null for restaurants
    time_slot = db.Column(db.String(10))   # "19:30" for restaurants

    guests = db.Column(db.Integer, default=1)
    total_price = db.Column(db.Float, default=0.0)
    special_requests = db.Column(db.Text)
    status = db.Column(db.String(20), default="pending")  # pending|confirmed|cancelled|completed
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def nights(self):
        if self.end_date and self.start_date:
            return max((self.end_date - self.start_date).days, 0)
        return 0

    @property
    def is_past(self):
        ref = self.end_date or self.start_date
        return ref < date.today()

    @property
    def status_color(self):
        return {
            "pending": "amber",
            "confirmed": "emerald",
            "cancelled": "rose",
            "completed": "slate",
        }.get(self.status, "slate")

    def __repr__(self):
        return f"<Reservation {self.code}>"


class Review(db.Model):
    """A customer review left after a stay/visit."""

    id = db.Column(db.Integer, primary_key=True)
    rating = db.Column(db.Integer, nullable=False)  # 1-5
    comment = db.Column(db.Text)
    sentiment = db.Column(db.String(20))  # positive | neutral | negative (AI-computed)
    sentiment_score = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    unit_id = db.Column(db.Integer, db.ForeignKey("unit.id"), nullable=False)

    def __repr__(self):
        return f"<Review {self.rating}★ on unit {self.unit_id}>"


class Favorite(db.Model):
    """A user's saved/favourite unit."""

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    unit_id = db.Column(db.Integer, db.ForeignKey("unit.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Notification(db.Model):
    """In-app notification for any user role."""

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    message = db.Column(db.String(255), nullable=False)
    link = db.Column(db.String(255))
    icon = db.Column(db.String(40), default="bell")
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
