"""Seed the StayPlate database with realistic demo data.

Run with:  python seed.py
Creates demo accounts, establishments, rooms/tables, reviews and reservations
so every feature — including the AI recommender, sentiment analysis,
demand forecasting and price advisor — has data to work with.
"""
from datetime import date, datetime, timedelta
import random

from app import create_app
from extensions import db
from models import (
    User, Amenity, Unit, Resource, Reservation, Review, Favorite, Notification,
)
from utils import gen_code
import ai_engine

app = create_app()


AMENITIES = [
    ("Free WiFi", "wifi"), ("Parking", "car"), ("Swimming Pool", "waves"),
    ("Fitness Center", "dumbbell"), ("Spa", "flower"), ("Restaurant", "utensils"),
    ("Bar", "wine"), ("Air Conditioning", "snowflake"), ("Pet Friendly", "paw-print"),
    ("Breakfast Included", "croissant"), ("Sea View", "sailboat"), ("Rooftop Terrace", "sun"),
    ("Outdoor Seating", "trees"), ("Live Music", "music"), ("Vegan Options", "salad"),
    ("Wheelchair Access", "accessibility"),
]

HOTELS = [
    {
        "name": "The Ivory Coast Resort", "city": "Saranda", "cuisine": None,
        "base_price": 165, "star_rating": 5, "featured": True,
        "desc": "A serene seafront retreat where the Ionian glows gold at sunset. Infinity pool, spa, and rooms that open straight onto the breeze.",
        "amenities": ["Free WiFi", "Swimming Pool", "Spa", "Sea View", "Breakfast Included", "Bar"],
        "rooms": [("Garden Double", 2, 165), ("Sea-View Suite", 3, 240), ("Family Loft", 5, 310)],
    },
    {
        "name": "Tirana Grand Boutique", "city": "Tirana", "cuisine": None,
        "base_price": 95, "star_rating": 4, "featured": True,
        "desc": "Industrial-chic boutique hotel in the heart of Blloku, steps from the city's best cafés and nightlife.",
        "amenities": ["Free WiFi", "Air Conditioning", "Fitness Center", "Rooftop Terrace", "Bar"],
        "rooms": [("Standard Queen", 2, 95), ("Deluxe King", 2, 130), ("Rooftop Studio", 3, 175)],
    },
    {
        "name": "Berat Stone House", "city": "Berat", "cuisine": None,
        "base_price": 70, "star_rating": 3, "featured": False,
        "desc": "A lovingly restored Ottoman house in the UNESCO old town. Wooden balconies, mountain views, and warm Albanian hospitality.",
        "amenities": ["Free WiFi", "Breakfast Included", "Pet Friendly", "Parking"],
        "rooms": [("Cozy Double", 2, 70), ("Balcony Room", 2, 90)],
    },
    {
        "name": "Riva Durrës Seafront", "city": "Durres", "cuisine": None,
        "base_price": 120, "star_rating": 4, "featured": False,
        "desc": "Modern beachfront comfort with a rooftop pool and direct sand access. Perfect for a sun-soaked weekend.",
        "amenities": ["Free WiFi", "Swimming Pool", "Sea View", "Air Conditioning", "Parking", "Wheelchair Access"],
        "rooms": [("Pool-View Double", 2, 120), ("Beachfront Suite", 4, 200)],
    },
]

RESTAURANTS = [
    {
        "name": "Mullixhiu", "city": "Tirana", "cuisine": "Modern Albanian",
        "base_price": 38, "featured": True,
        "desc": "Farm-to-table Albanian cuisine reinvented. Hand-milled grains, foraged herbs, and a tasting menu that tells a story.",
        "amenities": ["Outdoor Seating", "Vegan Options", "Live Music", "Air Conditioning"],
        "tables": [("Window Table for 2", 2, 38), ("Garden Table for 4", 4, 38), ("Chef's Counter", 6, 55)],
    },
    {
        "name": "Mare Nostrum", "city": "Saranda", "cuisine": "Seafood Mediterranean",
        "base_price": 45, "featured": True,
        "desc": "Just-caught seafood served on a terrace above the harbour. Grilled octopus, sea bass, and crisp local white wine.",
        "amenities": ["Sea View", "Outdoor Seating", "Bar", "Wheelchair Access"],
        "tables": [("Terrace Two-Top", 2, 45), ("Harbour Table", 4, 45), ("Private Alcove", 8, 60)],
    },
    {
        "name": "Trattoria Vesuvio", "city": "Durres", "cuisine": "Italian",
        "base_price": 28, "featured": False,
        "desc": "A neighbourhood trattoria with a wood-fired oven, house-made pasta, and tiramisu worth the trip alone.",
        "amenities": ["Outdoor Seating", "Vegan Options", "Pet Friendly"],
        "tables": [("Bistro Table", 2, 28), ("Family Table", 6, 28)],
    },
    {
        "name": "Sky Lounge 360", "city": "Tirana", "cuisine": "Fusion",
        "base_price": 52, "featured": False,
        "desc": "Panoramic rooftop dining with an inventive fusion menu and craft cocktails as the city lights flicker on.",
        "amenities": ["Rooftop Terrace", "Bar", "Live Music", "Air Conditioning", "Vegan Options"],
        "tables": [("Skyline Two-Top", 2, 52), ("Lounge Booth", 5, 60)],
    },
]

REVIEW_TEXTS = [
    (5, "Absolutely wonderful stay! The staff were incredibly friendly and the views were breathtaking. Highly recommend."),
    (5, "An unforgettable experience. Spotless, beautiful, and the breakfast was delicious. We'll definitely be back!"),
    (4, "Really lovely place, great location and very comfortable. The room was a touch small but everything else was perfect."),
    (4, "Great value for the price. Friendly service and a fantastic atmosphere. Would happily return."),
    (3, "Decent overall. The location was convenient but the service felt a bit slow at times. Average experience."),
    (2, "Disappointing, unfortunately. The room was not very clean and the staff seemed disinterested. Expected more."),
    (5, "The food was extraordinary — every dish was a delight. Best meal we've had in years!"),
    (4, "Charming spot with delicious food. A little noisy but the flavours more than made up for it."),
]

CUSTOMER_PREFS = [
    "sea view, seafood, luxury", "italian, outdoor seating, mid",
    "modern albanian, vegan, rooftop terrace", "budget, breakfast included, pet friendly",
]


def run():
    with app.app_context():
        print("Resetting database…")
        db.drop_all()
        db.create_all()

        # ---- Amenities ----
        amenity_map = {}
        for name, icon in AMENITIES:
            a = Amenity(name=name, icon=icon)
            db.session.add(a)
            amenity_map[name] = a
        db.session.commit()

        # ---- Admin ----
        admin = User(full_name="Ava Admin", email="admin@stayplate.com",
                     role="admin", phone="+355 69 000 0001")
        admin.set_password("admin123")
        db.session.add(admin)

        # ---- Managers ----
        m1 = User(full_name="Marco Host", email="manager@stayplate.com",
                  role="manager", phone="+355 69 000 0002")
        m1.set_password("manager123")
        m2 = User(full_name="Elira Pana", email="elira@stayplate.com",
                  role="manager", phone="+355 69 000 0003")
        m2.set_password("manager123")
        db.session.add_all([m1, m2])

        # ---- Customers ----
        customers = []
        names = [("Liam Customer", "user@stayplate.com"),
                 ("Sofia Reyes", "sofia@stayplate.com"),
                 ("Noah Brown", "noah@stayplate.com"),
                 ("Mia Hoxha", "mia@stayplate.com")]
        for i, (nm, em) in enumerate(names):
            c = User(full_name=nm, email=em, role="user",
                     preferences=CUSTOMER_PREFS[i % len(CUSTOMER_PREFS)],
                     phone=f"+355 69 111 00{i:02d}")
            c.set_password("user123")
            customers.append(c)
        db.session.add_all(customers)
        db.session.commit()

        # ---- Establishments ----
        all_units = []
        managers = [m1, m2]
        for idx, spec in enumerate(HOTELS):
            unit = Unit(
                name=spec["name"], type="hotel", description=spec["desc"],
                city=spec["city"], address=f"{spec['city']} center",
                base_price=spec["base_price"], capacity=spec["rooms"][0][1],
                star_rating=spec["star_rating"], status="approved",
                is_featured=spec["featured"], manager_id=managers[idx % 2].id,
                created_at=datetime.utcnow() - timedelta(days=random.randint(40, 160)),
            )
            unit.amenities = [amenity_map[a] for a in spec["amenities"] if a in amenity_map]
            db.session.add(unit)
            db.session.flush()
            for rn, cap, price in spec["rooms"]:
                db.session.add(Resource(name=rn, capacity=cap, price=price,
                                        unit_id=unit.id, is_active=True,
                                        description="Comfortable and well-appointed."))
            all_units.append(unit)

        for idx, spec in enumerate(RESTAURANTS):
            unit = Unit(
                name=spec["name"], type="restaurant", description=spec["desc"],
                city=spec["city"], address=f"{spec['city']} center",
                base_price=spec["base_price"], capacity=spec["tables"][0][1],
                cuisine=spec["cuisine"], status="approved",
                is_featured=spec["featured"], manager_id=managers[idx % 2].id,
                created_at=datetime.utcnow() - timedelta(days=random.randint(30, 140)),
            )
            unit.amenities = [amenity_map[a] for a in spec["amenities"] if a in amenity_map]
            db.session.add(unit)
            db.session.flush()
            for tn, cap, price in spec["tables"]:
                db.session.add(Resource(name=tn, capacity=cap, price=price,
                                        unit_id=unit.id, is_active=True,
                                        description="A great spot to enjoy your meal."))
            all_units.append(unit)

        # One pending establishment to demonstrate admin approval flow
        pending = Unit(
            name="Lakeside Pavilion", type="restaurant", description="A brand-new lakeside dining concept awaiting approval.",
            city="Shkoder", address="Lake promenade", base_price=34, capacity=4,
            cuisine="Grill", status="pending", manager_id=m2.id,
        )
        pending.amenities = [amenity_map["Outdoor Seating"], amenity_map["Bar"]]
        db.session.add(pending)
        db.session.flush()
        db.session.add(Resource(name="Lakeside Table", capacity=4, price=34, unit_id=pending.id))
        db.session.commit()

        # ---- Reservations + Reviews ----
        today = date.today()
        for unit in all_units:
            resources = unit.resources
            n_res = random.randint(4, 9)
            for _ in range(n_res):
                cust = random.choice(customers)
                resource = random.choice(resources)
                offset = random.randint(-45, 25)
                start = today + timedelta(days=offset)
                if unit.type == "hotel":
                    nights = random.randint(1, 4)
                    end = start + timedelta(days=nights)
                    total = nights * resource.price
                    time_slot = None
                else:
                    end = None
                    time_slot = random.choice(["13:00", "19:00", "19:30", "20:00", "20:30"])
                    total = resource.price * random.randint(1, resource.capacity)

                if offset < -2:
                    status = random.choice(["completed", "completed", "cancelled"])
                elif offset < 5:
                    status = random.choice(["confirmed", "completed"])
                else:
                    status = random.choice(["pending", "confirmed", "confirmed"])

                res = Reservation(
                    code=gen_code(), user_id=cust.id, unit_id=unit.id,
                    resource_id=resource.id, start_date=start, end_date=end,
                    time_slot=time_slot, guests=random.randint(1, resource.capacity),
                    total_price=total, status=status,
                    created_at=datetime.utcnow() - timedelta(days=max(0, -offset) + random.randint(1, 10)),
                )
                db.session.add(res)

            # Reviews (run AI sentiment analysis)
            reviewers = random.sample(customers, k=min(len(customers), random.randint(2, 4)))
            for cust in reviewers:
                rating, text = random.choice(REVIEW_TEXTS)
                label, score = ai_engine.analyze_sentiment(text)
                db.session.add(Review(
                    rating=rating, comment=text, sentiment=label, sentiment_score=score,
                    user_id=cust.id, unit_id=unit.id,
                    created_at=datetime.utcnow() - timedelta(days=random.randint(1, 30)),
                ))

        # A couple of favorites + a welcome notification
        db.session.add(Favorite(user_id=customers[0].id, unit_id=all_units[0].id))
        db.session.add(Favorite(user_id=customers[0].id, unit_id=all_units[4].id))
        for c in customers:
            db.session.add(Notification(user_id=c.id, message="Welcome to StayPlate! Discover your next stay.",
                                        link="/explore", icon="sparkles"))
        db.session.commit()

        print("\n Seed complete!\n")
        print("Demo accounts (password in parentheses):")
        print("  • Admin    →  admin@stayplate.com    (admin123)")
        print("  • Manager  →  manager@stayplate.com  (manager123)")
        print("  • Manager  →  elira@stayplate.com    (manager123)")
        print("  • Customer →  user@stayplate.com     (user123)")
        print(f"\n{Unit.query.count()} establishments · {Reservation.query.count()} reservations · {Review.query.count()} reviews")


if __name__ == "__main__":
    run()
