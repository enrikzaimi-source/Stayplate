# StayPlate — Smart Reservations for Hotels & Restaurants

StayPlate is a complete, production-style online reservation platform built with
**Flask**. It lets travellers discover and book hotels and restaurant tables,
lets owners manage their establishments, and gives administrators full oversight
— all wrapped in a warm, hand-crafted interface and powered by a built-in
**AI engine** (no external services required).

---

## ✨ Highlights

- **Three full roles** — Customer, Manager, and Administrator, each with its own
  dashboard and permissions.
- **Hotels *and* restaurants** — a single model handles nightly room stays and
  time-slot table reservations.
- **Five AI features**, all running offline out of the box (see below).
- **Polished, responsive UI** — custom design system, no heavy frameworks.
- **Error-free, role-protected backend** — clean Flask app-factory architecture
  with blueprints, WTForms validation, CSRF protection, and booking-conflict
  detection.

---

## 🧠 The AI engine

Everything below works with **zero configuration**. Add an `ANTHROPIC_API_KEY`
to upgrade the concierge to full natural-language replies.

| Feature | What it does |
|---|---|
| **Personal recommender** | Builds a taste profile from your preferences, bookings and reviews, then ranks places by cosine similarity — with a human-readable reason for each pick. |
| **Sentiment analysis** | Every review is scored positive / neutral / negative (with negation handling) and summarised into a sentiment bar on each listing. |
| **Smart concierge** | A chat assistant (bubble, bottom-right) that understands free text like *"romantic seafood dinner in Saranda under €50"* and finds matches. |
| **Demand forecasting** | Predicts 14-day occupancy per establishment using weekday/seasonal factors plus live bookings. |
| **Dynamic price advisor** | Suggests a low / optimal / premium price band from forecast demand and quality signals, with a plain-English verdict. |

---

## 🚀 Getting started

```bash
# 1. (recommended) create a virtual environment
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate

# 2. install dependencies
pip install -r requirements.txt

# 3. load demo data (creates the database + sample accounts/places)
python seed.py

# 4. run the app
python app.py
```

Then open **http://127.0.0.1:5000**.

> `seed.py` resets the database each time it runs, so use it whenever you want a
> clean, fully-populated demo.

---

## 🔑 Demo accounts

| Role | Email | Password |
|---|---|---|
| **Administrator** | `admin@stayplate.com` | `admin123` |
| **Manager** | `manager@stayplate.com` | `manager123` |
| **Manager** | `elira@stayplate.com` | `manager123` |
| **Customer** | `user@stayplate.com` | `user123` |

The seed also creates extra customers (`sofia@`, `noah@`, `mia@stayplate.com`,
all `user123`) and 9 establishments with reviews and reservations so the AI
features have real data to work with.

---

## 🗺️ What each role can do

**Customer** — browse & search, get AI recommendations, save favourites, book
rooms/tables, manage and cancel reservations, leave reviews, chat with the
concierge.

**Manager** — list hotels/restaurants (pending admin approval), manage rooms and
tables, confirm / complete / cancel reservations, and view AI demand forecasts
and pricing advice per establishment.

**Administrator** — platform dashboard with charts, approve / reject / feature
listings, manage users and roles, oversee every reservation, and curate the
amenity catalogue.

---

## ⚙️ Configuration

Copy `.env.example` to `.env` to customise settings:

- `SECRET_KEY` — set a long random value for production.
- `ANTHROPIC_API_KEY` — *optional*; enables richer concierge replies.
- `DATABASE_URL` — *optional*; defaults to local SQLite.

---

## 📁 Project structure

```
reservation_system/
├── app.py              # application factory, filters, error handlers
├── config.py           # configuration
├── extensions.py       # shared db / login-manager instances
├── models.py           # SQLAlchemy models
├── forms.py            # WTForms with validation
├── ai_engine.py        # the offline AI engine (5 features)
├── utils.py            # role decorator, notifications, codes
├── seed.py             # demo-data loader
├── requirements.txt
├── blueprints/         # auth, main, user, manager, admin, api
├── templates/          # Jinja2 templates (+ partials, macros)
└── static/             # css, js, images, uploads
```

---

## 🛠️ Tech stack

Flask · Flask-SQLAlchemy · Flask-Login · Flask-WTF / WTForms · SQLite ·
vanilla JavaScript · a custom CSS design system · Lucide icons.

Built to be read, extended, and deployed. Enjoy! 🏨🍽️
