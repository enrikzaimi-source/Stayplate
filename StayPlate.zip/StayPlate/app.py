"""StayPlate — application factory."""
import os
import uuid
from datetime import datetime
from flask import Flask, render_template
from werkzeug.utils import secure_filename

from config import Config
from extensions import db, login_manager


def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)

    from models import User

    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    # ---- Blueprints ----
    from blueprints.auth import auth_bp
    from blueprints.main import main_bp
    from blueprints.user import user_bp
    from blueprints.manager import manager_bp
    from blueprints.admin import admin_bp
    from blueprints.api import api_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(user_bp, url_prefix="/account")
    app.register_blueprint(manager_bp, url_prefix="/manager")
    app.register_blueprint(admin_bp, url_prefix="/admin")
    app.register_blueprint(api_bp, url_prefix="/api")

    # ---- Template globals & filters ----
    @app.context_processor
    def inject_globals():
        return {"now": datetime.utcnow(), "app_name": "StayPlate"}

    @app.template_filter("money")
    def money(value):
        try:
            return f"${value:,.0f}"
        except (TypeError, ValueError):
            return value

    @app.template_filter("stars")
    def stars(value):
        full = int(round(value or 0))
        return "★" * full + "☆" * (5 - full)

    # ---- Error handlers ----
    @app.errorhandler(403)
    def forbidden(e):
        return render_template("errors/error.html", code=403,
                               message="You don't have permission to view this page."), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template("errors/error.html", code=404,
                               message="The page you're looking for doesn't exist."), 404

    @app.errorhandler(500)
    def server_error(e):
        db.session.rollback()
        return render_template("errors/error.html", code=500,
                               message="Something went wrong on our end."), 500

    return app


def save_image(file_storage, upload_folder):
    """Save an uploaded image with a unique name; return the filename."""
    if not file_storage or not file_storage.filename:
        return None
    filename = secure_filename(file_storage.filename)
    ext = filename.rsplit(".", 1)[-1].lower()
    unique = f"{uuid.uuid4().hex}.{ext}"
    file_storage.save(os.path.join(upload_folder, unique))
    return unique


if __name__ == "__main__":
    app = create_app()
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5000)
