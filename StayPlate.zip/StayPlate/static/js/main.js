/* StayPlate — client interactions */
(function () {
  "use strict";

  // ---- Mobile nav toggle ----
  const toggle = document.querySelector(".nav-toggle");
  const links = document.querySelector(".nav-links");
  if (toggle && links) toggle.addEventListener("click", () => links.classList.toggle("open"));

  // ---- Dropdowns ----
  document.querySelectorAll(".dropdown > [data-dropdown]").forEach((trigger) => {
    trigger.addEventListener("click", (e) => {
      e.stopPropagation();
      const dd = trigger.closest(".dropdown");
      document.querySelectorAll(".dropdown.open").forEach((o) => { if (o !== dd) o.classList.remove("open"); });
      dd.classList.toggle("open");
    });
  });
  document.addEventListener("click", () =>
    document.querySelectorAll(".dropdown.open").forEach((o) => o.classList.remove("open"))
  );

  // ---- Flash auto-dismiss ----
  document.querySelectorAll(".flash").forEach((f) => {
    const close = f.querySelector("button");
    if (close) close.addEventListener("click", () => f.remove());
    setTimeout(() => { f.style.transition = "opacity .4s"; f.style.opacity = "0"; setTimeout(() => f.remove(), 400); }, 5000);
  });

  // ---- Scroll reveal ----
  const reveals = document.querySelectorAll(".reveal");
  if (reveals.length) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => { if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); } });
    }, { threshold: 0.12 });
    reveals.forEach((r) => io.observe(r));
  }

  // ---- Booking form: toggle hotel/restaurant fields ----
  const bookForm = document.querySelector("[data-book-type]");
  if (bookForm) {
    const type = bookForm.getAttribute("data-book-type");
    const endField = document.querySelector("[data-field-end]");
    const timeField = document.querySelector("[data-field-time]");
    if (type === "hotel") { if (timeField) timeField.style.display = "none"; }
    else { if (endField) endField.style.display = "none"; }
  }

  // ---- Animate bars on load ----
  document.querySelectorAll(".occ-fill[data-width]").forEach((el) => {
    const w = el.getAttribute("data-width");
    setTimeout(() => { el.style.width = w + "%"; }, 100);
  });
  document.querySelectorAll(".bar[data-height]").forEach((el) => {
    const h = el.getAttribute("data-height");
    setTimeout(() => { el.style.height = h + "%"; }, 100);
  });

  // ============================================================
  // AI CONCIERGE CHATBOT
  // ============================================================
  const fab = document.getElementById("ccFab");
  const panel = document.getElementById("ccPanel");
  const body = document.getElementById("ccBody");
  const input = document.getElementById("ccInput");
  const sendBtn = document.getElementById("ccSend");
  if (!fab || !panel) return;

  let greeted = false;
  fab.addEventListener("click", () => {
    panel.classList.toggle("open");
    if (panel.classList.contains("open") && !greeted) {
      greeted = true;
      botSay("Hi! I'm your StayPlate concierge ✨\nTell me what you're after — a hotel, a restaurant, a city, a budget — and I'll find the perfect match.");
      showSuggestions(["Hotel in Tirana under $120", "Italian restaurant for 4", "Romantic dinner with a sea view", "Family hotel with a pool"]);
      input.focus();
    }
  });
  document.getElementById("ccClose")?.addEventListener("click", () => panel.classList.remove("open"));

  function el(tag, cls, html) { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }
  function scrollDown() { body.scrollTop = body.scrollHeight; }

  function botSay(text) { const m = el("div", "cc-msg bot"); m.textContent = text; body.appendChild(m); scrollDown(); }
  function userSay(text) { const m = el("div", "cc-msg user"); m.textContent = text; body.appendChild(m); scrollDown(); }

  function showSuggestions(arr) {
    const wrap = el("div", "cc-suggestions");
    arr.forEach((s) => {
      const b = el("button", null, s);
      b.addEventListener("click", () => { input.value = s; sendMessage(); });
      wrap.appendChild(b);
    });
    body.appendChild(wrap); scrollDown();
  }

  function showTyping() {
    const t = el("div", "cc-msg bot cc-typing");
    t.id = "ccTyping";
    t.innerHTML = "<span></span><span></span><span></span>";
    body.appendChild(t); scrollDown();
  }
  function hideTyping() { document.getElementById("ccTyping")?.remove(); }

  function showUnits(units) {
    if (!units || !units.length) return;
    const wrap = el("div", "cc-units");
    units.forEach((u) => {
      const a = el("a", "cc-unit");
      a.href = u.url;
      const img = u.image ? `/static/uploads/${u.image}` : "";
      a.innerHTML =
        (img ? `<img src="${img}" onerror="this.style.display='none'">` : `<div style="width:48px;height:48px;border-radius:8px;background:var(--cream-2);display:grid;place-items:center">🏨</div>`) +
        `<div><div class="nm">${u.name}</div><div class="mt">${u.city} · ⭐ ${u.rating} · $${u.price}${u.price_label}</div></div>`;
      wrap.appendChild(a);
    });
    body.appendChild(wrap); scrollDown();
  }

  async function sendMessage() {
    const text = input.value.trim();
    if (!text) return;
    userSay(text);
    input.value = "";
    showTyping();
    try {
      const res = await fetch("/api/concierge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text }),
      });
      const data = await res.json();
      hideTyping();
      botSay(data.text);
      showUnits(data.units);
    } catch (err) {
      hideTyping();
      botSay("Sorry, I had trouble connecting. Please try again.");
    }
  }

  sendBtn?.addEventListener("click", sendMessage);
  input?.addEventListener("keydown", (e) => { if (e.key === "Enter") sendMessage(); });
})();
