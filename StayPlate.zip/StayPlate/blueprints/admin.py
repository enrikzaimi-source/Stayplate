"""Administrator routes: full platform oversight."""
from datetime import date, timedelta
from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from extensions import db
from models import User, Unit, Reservation, Review, Amenity
from utils import role_required, notify

admin_bp = Blueprint("admin", __name__)


@admin_bp.route("/")
@login_required
@role_required("admin")
def dashboard():
    users = User.query.all()
    units = Unit.query.all()
    reservations = Reservation.query.all()
    revenue = sum(r.total_price for r in reservations if r.status in ("confirmed", "completed"))

    stats = {
        "users": len([u for u in users if u.role == "user"]),
        "managers": len([u for u in users if u.role == "manager"]),
        "units": len(units),
        "pending_units": len([u for u in units if u.status == "pending"]),
        "reservations": len(reservations),
        "revenue": revenue,
        "reviews": Review.query.count(),
    }

    # Reservations per day (last 14 days)
    today = date.today()
    daily = []
    for i in range(13, -1, -1):
        d = today - timedelta(days=i)
        count = sum(1 for r in reservations if r.created_at.date() == d)
        daily.append({"label": d.strftime("%d/%m"), "value": count})

    type_split = {
        "hotel": len([u for u in units if u.type == "hotel"]),
        "restaurant": len([u for u in units if u.type == "restaurant"]),
    }
    pending = [u for u in units if u.status == "pending"]
    recent_res = sorted(reservations, key=lambda r: r.created_at, reverse=True)[:6]
    return render_template("admin/dashboard.html", stats=stats, daily=daily,
                           type_split=type_split, pending=pending[:5],
                           recent_res=recent_res)


@admin_bp.route("/users")
@login_required
@role_required("admin")
def users():
    role = request.args.get("role", "all")
    q = request.args.get("q", "").strip()
    query = User.query
    if role != "all":
        query = query.filter_by(role=role)
    if q:
        query = query.filter(User.full_name.ilike(f"%{q}%") | User.email.ilike(f"%{q}%"))
    items = query.order_by(User.created_at.desc()).all()
    return render_template("admin/users.html", users=items, role=role, q=q)


@admin_bp.route("/users/<int:user_id>/toggle", methods=["POST"])
@login_required
@role_required("admin")
def toggle_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("You can't suspend your own account.", "warning")
        return redirect(url_for("admin.users"))
    user.is_active = not user.is_active
    db.session.commit()
    flash(f"{user.full_name} {'activated' if user.is_active else 'suspended'}.", "info")
    return redirect(url_for("admin.users"))


@admin_bp.route("/users/<int:user_id>/role", methods=["POST"])
@login_required
@role_required("admin")
def change_role(user_id):
    user = User.query.get_or_404(user_id)
    new_role = request.form.get("role")
    if new_role in ("user", "manager", "admin"):
        user.role = new_role
        db.session.commit()
        flash(f"{user.full_name} is now a {new_role}.", "success")
    return redirect(url_for("admin.users"))


@admin_bp.route("/units")
@login_required
@role_required("admin")
def units():
    status = request.args.get("status", "all")
    query = Unit.query
    if status != "all":
        query = query.filter_by(status=status)
    items = query.order_by(Unit.created_at.desc()).all()
    return render_template("admin/units.html", units=items, status=status)


@admin_bp.route("/units/<int:unit_id>/<action>", methods=["POST"])
@login_required
@role_required("admin")
def unit_action(unit_id, action):
    unit = Unit.query.get_or_404(unit_id)
    if action == "approve":
        unit.status = "approved"
        notify(unit.manager_id, f"'{unit.name}' was approved and is now live!",
               url_for("manager.unit_detail", unit_id=unit.id), icon="check-circle")
        flash(f"{unit.name} approved.", "success")
    elif action == "reject":
        unit.status = "rejected"
        notify(unit.manager_id, f"'{unit.name}' was not approved.",
               url_for("manager.units"), icon="x-circle")
        flash(f"{unit.name} rejected.", "info")
    elif action == "feature":
        unit.is_featured = not unit.is_featured
        flash(f"{unit.name} {'featured' if unit.is_featured else 'unfeatured'}.", "info")
    elif action == "delete":
        db.session.delete(unit)
        db.session.commit()
        flash(f"{unit.name} deleted.", "info")
        return redirect(url_for("admin.units"))
    else:
        abort(400)
    db.session.commit()
    return redirect(request.referrer or url_for("admin.units"))


@admin_bp.route("/reservations")
@login_required
@role_required("admin")
def reservations():
    status = request.args.get("status", "all")
    query = Reservation.query
    if status != "all":
        query = query.filter_by(status=status)
    items = query.order_by(Reservation.created_at.desc()).limit(200).all()
    return render_template("admin/reservations.html", reservations=items, status=status)


@admin_bp.route("/amenities", methods=["GET", "POST"])
@login_required
@role_required("admin")
def amenities():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        icon = request.form.get("icon", "star").strip() or "star"
        if name and not Amenity.query.filter_by(name=name).first():
            db.session.add(Amenity(name=name, icon=icon))
            db.session.commit()
            flash(f"Amenity '{name}' added.", "success")
        else:
            flash("Amenity already exists or name is empty.", "warning")
        return redirect(url_for("admin.amenities"))
    items = Amenity.query.order_by(Amenity.name).all()
    return render_template("admin/amenities.html", amenities=items)


@admin_bp.route("/amenities/<int:amenity_id>/delete", methods=["POST"])
@login_required
@role_required("admin")
def amenity_delete(amenity_id):
    am = Amenity.query.get_or_404(amenity_id)
    db.session.delete(am)
    db.session.commit()
    flash("Amenity removed.", "info")
    return redirect(url_for("admin.amenities"))
