"""Manager routes: manage establishments, resources, reservations, AI insights."""
from datetime import date
from flask import (
    Blueprint, render_template, redirect, url_for, flash, request, abort, current_app,
)
from flask_login import login_required, current_user
from extensions import db
from models import Unit, Resource, Reservation, Amenity, Review
from forms import UnitForm, ResourceForm
from utils import role_required, notify
from app import save_image
import ai_engine

manager_bp = Blueprint("manager", __name__)


def _owned_unit_or_404(unit_id):
    unit = Unit.query.get_or_404(unit_id)
    if unit.manager_id != current_user.id and not current_user.is_admin:
        abort(403)
    return unit


@manager_bp.route("/")
@login_required
@role_required("manager", "admin")
def dashboard():
    units = Unit.query.filter_by(manager_id=current_user.id).all()
    unit_ids = [u.id for u in units]
    reservations = Reservation.query.filter(Reservation.unit_id.in_(unit_ids or [-1])).all()

    revenue = sum(r.total_price for r in reservations if r.status in ("confirmed", "completed"))
    pending = [r for r in reservations if r.status == "pending"]
    stats = {
        "units": len(units),
        "approved": len([u for u in units if u.status == "approved"]),
        "reservations": len(reservations),
        "pending": len(pending),
        "revenue": revenue,
        "reviews": sum(u.review_count for u in units),
        "avg_rating": round(
            sum(u.avg_rating * u.review_count for u in units) /
            max(sum(u.review_count for u in units), 1), 1),
    }

    # Revenue trend (last 6 months)
    from collections import OrderedDict
    trend = OrderedDict()
    today = date.today()
    for i in range(5, -1, -1):
        m = (today.month - i - 1) % 12 + 1
        y = today.year + ((today.month - i - 1) // 12)
        trend[f"{y}-{m:02d}"] = 0
    for r in reservations:
        if r.status in ("confirmed", "completed"):
            key = r.created_at.strftime("%Y-%m")
            if key in trend:
                trend[key] += r.total_price
    revenue_trend = [{"month": k[5:], "value": round(v)} for k, v in trend.items()]

    recent = sorted(reservations, key=lambda r: r.created_at, reverse=True)[:6]
    return render_template("manager/dashboard.html", stats=stats, units=units,
                           recent=recent, pending=pending[:5],
                           revenue_trend=revenue_trend)


@manager_bp.route("/units")
@login_required
@role_required("manager", "admin")
def units():
    items = Unit.query.filter_by(manager_id=current_user.id).order_by(
        Unit.created_at.desc()).all()
    return render_template("manager/units.html", units=items)


@manager_bp.route("/units/new", methods=["GET", "POST"])
@login_required
@role_required("manager", "admin")
def unit_new():
    form = UnitForm()
    form.amenities.choices = [(a.id, a.name) for a in Amenity.query.all()]
    if form.validate_on_submit():
        unit = Unit(
            name=form.name.data.strip(), type=form.type.data,
            description=form.description.data, city=form.city.data.strip(),
            address=form.address.data, base_price=form.base_price.data,
            capacity=form.capacity.data, cuisine=form.cuisine.data,
            star_rating=int(form.star_rating.data), manager_id=current_user.id,
            status="pending",
        )
        if form.image.data:
            fname = save_image(form.image.data, current_app.config["UPLOAD_FOLDER"])
            if fname:
                unit.image = fname
        unit.amenities = Amenity.query.filter(Amenity.id.in_(form.amenities.data)).all()
        db.session.add(unit)
        # Notify admins for approval
        from models import User
        for admin in User.query.filter_by(role="admin").all():
            notify(admin.id, f"New establishment '{unit.name}' awaiting approval.",
                   url_for("admin.units"), icon="building")
        db.session.commit()
        flash("Establishment submitted! It will be visible once approved.", "success")
        return redirect(url_for("manager.unit_detail", unit_id=unit.id))
    return render_template("manager/unit_form.html", form=form, title="New establishment")


@manager_bp.route("/units/<int:unit_id>/edit", methods=["GET", "POST"])
@login_required
@role_required("manager", "admin")
def unit_edit(unit_id):
    unit = _owned_unit_or_404(unit_id)
    form = UnitForm(obj=unit)
    form.amenities.choices = [(a.id, a.name) for a in Amenity.query.all()]
    if request.method == "GET":
        form.amenities.data = [a.id for a in unit.amenities]
        form.star_rating.data = str(unit.star_rating)
    if form.validate_on_submit():
        unit.name = form.name.data.strip()
        unit.type = form.type.data
        unit.description = form.description.data
        unit.city = form.city.data.strip()
        unit.address = form.address.data
        unit.base_price = form.base_price.data
        unit.capacity = form.capacity.data
        unit.cuisine = form.cuisine.data
        unit.star_rating = int(form.star_rating.data)
        if form.image.data:
            fname = save_image(form.image.data, current_app.config["UPLOAD_FOLDER"])
            if fname:
                unit.image = fname
        unit.amenities = Amenity.query.filter(Amenity.id.in_(form.amenities.data)).all()
        db.session.commit()
        flash("Establishment updated.", "success")
        return redirect(url_for("manager.unit_detail", unit_id=unit.id))
    return render_template("manager/unit_form.html", form=form, title="Edit establishment", unit=unit)


@manager_bp.route("/units/<int:unit_id>")
@login_required
@role_required("manager", "admin")
def unit_detail(unit_id):
    unit = _owned_unit_or_404(unit_id)
    forecast = ai_engine.forecast_demand(unit, days=14)
    pricing = ai_engine.suggest_price(unit)
    # Review sentiment breakdown
    sentiments = {"positive": 0, "neutral": 0, "negative": 0}
    for r in unit.reviews:
        sentiments[r.sentiment or "neutral"] = sentiments.get(r.sentiment or "neutral", 0) + 1
    return render_template("manager/unit_detail.html", unit=unit, forecast=forecast,
                           pricing=pricing, sentiments=sentiments)


@manager_bp.route("/units/<int:unit_id>/delete", methods=["POST"])
@login_required
@role_required("manager", "admin")
def unit_delete(unit_id):
    unit = _owned_unit_or_404(unit_id)
    db.session.delete(unit)
    db.session.commit()
    flash("Establishment deleted.", "info")
    return redirect(url_for("manager.units"))


# ---- Resources (rooms/tables) ----
@manager_bp.route("/units/<int:unit_id>/resources/new", methods=["GET", "POST"])
@login_required
@role_required("manager", "admin")
def resource_new(unit_id):
    unit = _owned_unit_or_404(unit_id)
    form = ResourceForm()
    if request.method == "GET":
        form.capacity.data = unit.capacity
        form.price.data = unit.base_price
    if form.validate_on_submit():
        res = Resource(
            name=form.name.data.strip(), capacity=form.capacity.data,
            price=form.price.data, description=form.description.data,
            is_active=form.is_active.data, unit_id=unit.id,
        )
        db.session.add(res)
        db.session.commit()
        flash(f"{unit.unit_label} added.", "success")
        return redirect(url_for("manager.unit_detail", unit_id=unit.id))
    return render_template("manager/resource_form.html", form=form, unit=unit, title=f"New {unit.unit_label}")


@manager_bp.route("/resources/<int:resource_id>/edit", methods=["GET", "POST"])
@login_required
@role_required("manager", "admin")
def resource_edit(resource_id):
    res = Resource.query.get_or_404(resource_id)
    unit = _owned_unit_or_404(res.unit_id)
    form = ResourceForm(obj=res)
    if form.validate_on_submit():
        res.name = form.name.data.strip()
        res.capacity = form.capacity.data
        res.price = form.price.data
        res.description = form.description.data
        res.is_active = form.is_active.data
        db.session.commit()
        flash(f"{unit.unit_label} updated.", "success")
        return redirect(url_for("manager.unit_detail", unit_id=unit.id))
    return render_template("manager/resource_form.html", form=form, unit=unit, title=f"Edit {unit.unit_label}")


@manager_bp.route("/resources/<int:resource_id>/delete", methods=["POST"])
@login_required
@role_required("manager", "admin")
def resource_delete(resource_id):
    res = Resource.query.get_or_404(resource_id)
    unit = _owned_unit_or_404(res.unit_id)
    db.session.delete(res)
    db.session.commit()
    flash(f"{unit.unit_label} removed.", "info")
    return redirect(url_for("manager.unit_detail", unit_id=unit.id))


# ---- Reservations ----
@manager_bp.route("/reservations")
@login_required
@role_required("manager", "admin")
def reservations():
    status = request.args.get("status", "all")
    unit_ids = [u.id for u in Unit.query.filter_by(manager_id=current_user.id).all()]
    query = Reservation.query.filter(Reservation.unit_id.in_(unit_ids or [-1]))
    if status != "all":
        query = query.filter_by(status=status)
    items = query.order_by(Reservation.created_at.desc()).all()
    return render_template("manager/reservations.html", reservations=items, status=status)


@manager_bp.route("/reservations/<int:res_id>/<action>", methods=["POST"])
@login_required
@role_required("manager", "admin")
def reservation_action(res_id, action):
    res = Reservation.query.get_or_404(res_id)
    _owned_unit_or_404(res.unit_id)
    mapping = {"confirm": "confirmed", "cancel": "cancelled", "complete": "completed"}
    if action not in mapping:
        abort(400)
    res.status = mapping[action]
    notify(res.user_id,
           f"Your reservation {res.code} was {mapping[action]}.",
           url_for("user.reservation_detail", code=res.code),
           icon="calendar-check" if action != "cancel" else "x-circle")
    db.session.commit()
    flash(f"Reservation {res.code} {mapping[action]}.", "success")
    return redirect(request.referrer or url_for("manager.reservations"))


@manager_bp.route("/insights")
@login_required
@role_required("manager", "admin")
def insights():
    units = Unit.query.filter_by(manager_id=current_user.id, status="approved").all()
    data = []
    for u in units:
        data.append({
            "unit": u,
            "forecast": ai_engine.forecast_demand(u, days=14),
            "pricing": ai_engine.suggest_price(u),
        })
    return render_template("manager/insights.html", data=data)
