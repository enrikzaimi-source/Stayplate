"""Customer account routes."""
from datetime import date
from flask import (
    Blueprint, render_template, redirect, url_for, flash, request, abort, current_app,
)
from flask_login import login_required, current_user
from extensions import db
from models import Reservation, Favorite, Unit, Notification
from forms import ProfileForm, PasswordForm
from utils import role_required, notify
from app import save_image
import ai_engine

user_bp = Blueprint("user", __name__)


@user_bp.route("/")
@login_required
@role_required("user")
def dashboard():
    res = Reservation.query.filter_by(user_id=current_user.id).order_by(
        Reservation.created_at.desc()).all()
    upcoming = [r for r in res if not r.is_past and r.status in ("pending", "confirmed")]
    stats = {
        "total": len(res),
        "upcoming": len(upcoming),
        "completed": len([r for r in res if r.status == "completed"]),
        "favorites": Favorite.query.filter_by(user_id=current_user.id).count(),
    }
    recs = ai_engine.recommend_units(current_user, Unit.query.all(), limit=3)
    recommendations = [(u, reason) for u, _, reason in recs]
    return render_template("user/dashboard.html", upcoming=upcoming[:4],
                           recent=res[:5], stats=stats, recommendations=recommendations)


@user_bp.route("/reservations")
@login_required
@role_required("user")
def reservations():
    status = request.args.get("status", "all")
    query = Reservation.query.filter_by(user_id=current_user.id)
    if status != "all":
        query = query.filter_by(status=status)
    items = query.order_by(Reservation.created_at.desc()).all()
    return render_template("user/reservations.html", reservations=items, status=status)


@user_bp.route("/reservation/<code>")
@login_required
@role_required("user")
def reservation_detail(code):
    res = Reservation.query.filter_by(code=code).first_or_404()
    if res.user_id != current_user.id:
        abort(403)
    return render_template("user/reservation_detail.html", res=res)


@user_bp.route("/reservation/<code>/cancel", methods=["POST"])
@login_required
@role_required("user")
def cancel_reservation(code):
    res = Reservation.query.filter_by(code=code).first_or_404()
    if res.user_id != current_user.id:
        abort(403)
    if res.status in ("pending", "confirmed") and not res.is_past:
        res.status = "cancelled"
        notify(res.unit.manager_id, f"Reservation {res.code} was cancelled by the guest.",
               url_for("manager.reservations"), icon="x-circle")
        db.session.commit()
        flash("Reservation cancelled.", "info")
    else:
        flash("This reservation can no longer be cancelled.", "warning")
    return redirect(url_for("user.reservations"))


@user_bp.route("/favorites")
@login_required
@role_required("user")
def favorites():
    favs = Favorite.query.filter_by(user_id=current_user.id).all()
    units = [f.unit for f in favs if f.unit and f.unit.status == "approved"]
    return render_template("user/favorites.html", units=units)


@user_bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    form = ProfileForm(obj=current_user)
    pwd_form = PasswordForm()
    if form.submit.data and form.validate_on_submit():
        current_user.full_name = form.full_name.data.strip()
        current_user.phone = form.phone.data
        current_user.preferences = form.preferences.data
        if form.avatar.data:
            fname = save_image(form.avatar.data, current_app.config["UPLOAD_FOLDER"])
            if fname:
                current_user.avatar = fname
        db.session.commit()
        flash("Profile updated.", "success")
        return redirect(url_for("user.profile"))
    return render_template("user/profile.html", form=form, pwd_form=pwd_form)


@user_bp.route("/password", methods=["POST"])
@login_required
def change_password():
    pwd_form = PasswordForm()
    if pwd_form.validate_on_submit():
        if not current_user.check_password(pwd_form.current.data):
            flash("Current password is incorrect.", "danger")
        else:
            current_user.set_password(pwd_form.new.data)
            db.session.commit()
            flash("Password updated.", "success")
    else:
        flash("Could not update password.", "danger")
    return redirect(url_for("user.profile"))


@user_bp.route("/notifications")
@login_required
def notifications():
    notes = Notification.query.filter_by(user_id=current_user.id).order_by(
        Notification.created_at.desc()).all()
    for n in notes:
        n.is_read = True
    db.session.commit()
    return render_template("user/notifications.html", notes=notes)
