"""JSON API endpoints (AI concierge chatbot)."""
from flask import Blueprint, request, jsonify, url_for, current_app
from models import Unit
import ai_engine

api_bp = Blueprint("api", __name__)


@api_bp.route("/concierge", methods=["POST"])
def concierge():
    data = request.get_json(silent=True) or {}
    message = (data.get("message") or "").strip()
    if not message:
        return jsonify({"text": "Tell me what you're looking for!", "units": []})

    units = Unit.query.all()
    api_key = current_app.config.get("ANTHROPIC_API_KEY", "")
    result = ai_engine.concierge_reply(message, units, api_key=api_key)

    payload_units = []
    for u in result["units"]:
        payload_units.append({
            "id": u.id,
            "name": u.name,
            "type": u.type,
            "city": u.city,
            "rating": u.avg_rating,
            "price": round(u.base_price),
            "price_label": u.price_label,
            "cuisine": u.cuisine,
            "image": u.image,
            "url": url_for("main.unit_detail", unit_id=u.id),
        })
    return jsonify({"text": result["text"], "units": payload_units})


@api_bp.route("/suggest")
def suggest():
    """Lightweight autocomplete for the search bar."""
    q = (request.args.get("q") or "").lower().strip()
    if not q:
        return jsonify([])
    units = Unit.query.filter_by(status="approved").all()
    out = []
    for u in units:
        if q in u.name.lower() or (u.city and q in u.city.lower()):
            out.append({"name": u.name, "city": u.city,
                        "url": url_for("main.unit_detail", unit_id=u.id)})
        if len(out) >= 6:
            break
    return jsonify(out)
