"""Public + booking routes."""
from datetime import date, datetime, timedelta
from flask import (
    Blueprint, render_template, request, redirect, url_for, flash, abort, current_app,
)
from flask_login import current_user, login_required
from sqlalchemy import or_
from extensions import db
from models import Unit, Resource, Reservation, Review, Favorite, Amenity
from forms import ReservationForm, ReviewForm
from utils import gen_code, notify
import ai_engine

main_bp = Blueprint("main", __name__)


@main_bp.route("/")
def index():
    featured = Unit.query.filter_by(status="approved", is_featured=True).limit(6).all()
    if len(featured) < 6:
        extra = (Unit.query.filter_by(status="approved")
                 .order_by(Unit.created_at.desc()).limit(6 - len(featured)).all())
        featured += [u for u in extra if u not in featured]
    top_hotels = (Unit.query.filter_by(status="approved", type="hotel").all())
    top_hotels.sort(key=lambda u: u.avg_rating, reverse=True)
    top_restaurants = (Unit.query.filter_by(status="approved", type="restaurant").all())
    top_restaurants.sort(key=lambda u: u.avg_rating, reverse=True)

    recommendations = []
    if current_user.is_authenticated and current_user.role == "user":
        recs = ai_engine.recommend_units(current_user, Unit.query.all(), limit=3)
        recommendations = [(u, reason) for u, _, reason in recs]

    cities = [c[0] for c in db.session.query(Unit.city).filter_by(status="approved").distinct() if c[0]]
    return render_template(
        "index.html",
        featured=featured,
        top_hotels=top_hotels[:3],
        top_restaurants=top_restaurants[:3],
        recommendations=recommendations,
        cities=sorted(set(cities)),
        stats={
            "units": Unit.query.filter_by(status="approved").count(),
            "reservations": Reservation.query.count(),
            "cities": len(set(cities)),
        },
    )


@main_bp.route("/explore")
def explore():
    q = request.args.get("q", "").strip()
    utype = request.args.get("type", "")
    city = request.args.get("city", "")
    sort = request.args.get("sort", "rating")
    max_price = request.args.get("max_price", type=float)
    page = request.args.get("page", 1, type=int)

    query = Unit.query.filter_by(status="approved")
    if q:
        like = f"%{q}%"
        query = query.filter(or_(Unit.name.ilike(like), Unit.description.ilike(like),
                                 Unit.city.ilike(like), Unit.cuisine.ilike(like)))
    if utype in ("hotel", "restaurant"):
        query = query.filter_by(type=utype)
    if city:
        query = query.filter(Unit.city.ilike(f"%{city}%"))
    if max_price:
        query = query.filter(Unit.base_price <= max_price)

    units = query.all()
    if sort == "price_low":
        units.sort(key=lambda u: u.base_price)
    elif sort == "price_high":
        units.sort(key=lambda u: u.base_price, reverse=True)
    elif sort == "newest":
        units.sort(key=lambda u: u.created_at, reverse=True)
    else:
        units.sort(key=lambda u: u.avg_rating, reverse=True)

    per = current_app.config["ITEMS_PER_PAGE"]
    total = len(units)
    units_page = units[(page - 1) * per: page * per]
    pages = max((total + per - 1) // per, 1)

    cities = [c[0] for c in db.session.query(Unit.city).filter_by(status="approved").distinct() if c[0]]
    return render_template(
        "explore.html", units=units_page, total=total, page=page, pages=pages,
        q=q, utype=utype, city=city, sort=sort, max_price=max_price,
        cities=sorted(set(cities)),
    )


@main_bp.route("/unit/<int:unit_id>")
def unit_detail(unit_id):
    unit = Unit.query.get_or_404(unit_id)
    if unit.status != "approved" and not (
        current_user.is_authenticated and
        (current_user.is_admin or current_user.id == unit.manager_id)
    ):
        abort(404)

    reviews = sorted(unit.reviews, key=lambda r: r.created_at, reverse=True)
    is_fav = False
    can_review = False
    if current_user.is_authenticated:
        is_fav = Favorite.query.filter_by(user_id=current_user.id, unit_id=unit.id).first() is not None
        completed = Reservation.query.filter_by(
            user_id=current_user.id, unit_id=unit.id).filter(
            Reservation.status.in_(["completed", "confirmed"])).first()
        already = Review.query.filter_by(user_id=current_user.id, unit_id=unit.id).first()
        can_review = completed is not None and already is None

    # AI: sentiment summary
    sentiments = {"positive": 0, "neutral": 0, "negative": 0}
    for r in reviews:
        sentiments[r.sentiment or "neutral"] = sentiments.get(r.sentiment or "neutral", 0) + 1

    similar = ai_engine.search_units(
        {"type": unit.type, "city": (unit.city or "").lower(), "guests": None,
         "max_price": None, "amenities": [], "cuisine": None},
        Unit.query.all(), limit=4)
    similar = [u for u in similar if u.id != unit.id][:3]

    return render_template(
        "unit_detail.html", unit=unit, reviews=reviews, is_fav=is_fav,
        can_review=can_review, sentiments=sentiments, similar=similar,
        review_form=ReviewForm(), today=date.today().isoformat(),
    )


@main_bp.route("/unit/<int:unit_id>/book", methods=["GET", "POST"])
@login_required
def book(unit_id):
    if current_user.role != "user":
        flash("Only customer accounts can make reservations.", "warning")
        return redirect(url_for("main.unit_detail", unit_id=unit_id))

    unit = Unit.query.get_or_404(unit_id)
    if unit.status != "approved":
        abort(404)

    active_resources = [r for r in unit.resources if r.is_active]
    if not active_resources:
        flash("This establishment has no available units to book right now.", "warning")
        return redirect(url_for("main.unit_detail", unit_id=unit_id))

    form = ReservationForm()
    form.resource_id.choices = [
        (r.id, f"{r.name} · up to {r.capacity} guests · ${r.price:.0f}{unit.price_label}")
        for r in active_resources
    ]

    if form.validate_on_submit():
        resource = db.session.get(Resource, form.resource_id.data)
        if not resource or resource.unit_id != unit.id or not resource.is_active:
            flash("Invalid selection.", "danger")
            return render_template("book.html", unit=unit, form=form)

        start = form.start_date.data
        if start < date.today():
            flash("Start date can't be in the past.", "danger")
            return render_template("book.html", unit=unit, form=form)

        if form.guests.data > resource.capacity:
            flash(f"That selection holds up to {resource.capacity} guests.", "danger")
            return render_template("book.html", unit=unit, form=form)

        if unit.type == "hotel":
            end = form.end_date.data
            if not end or end <= start:
                flash("Check-out must be after check-in.", "danger")
                return render_template("book.html", unit=unit, form=form)
            nights = (end - start).days
            total = nights * resource.price
            time_slot = None
        else:
            end = None
            time_slot = form.time_slot.data or "19:00"
            total = resource.price * form.guests.data

        # Conflict check
        clash = _has_conflict(resource, start, end, time_slot)
        if clash:
            flash("Those dates/time are already booked for this selection. Try another.", "warning")
            return render_template("book.html", unit=unit, form=form)

        res = Reservation(
            code=gen_code(), user_id=current_user.id, unit_id=unit.id,
            resource_id=resource.id, start_date=start, end_date=end,
            time_slot=time_slot, guests=form.guests.data, total_price=total,
            special_requests=form.special_requests.data, status="pending",
        )
        db.session.add(res)
        notify(unit.manager_id,
               f"New reservation for {unit.name} ({res.code})",
               url_for("manager.reservations"), icon="calendar-check")
        db.session.commit()
        flash(f"Reservation {res.code} created! Awaiting confirmation.", "success")
        return redirect(url_for("user.reservation_detail", code=res.code))

    # Defaults
    if request.method == "GET":
        form.start_date.data = date.today() + timedelta(days=1)
        if unit.type == "hotel":
            form.end_date.data = date.today() + timedelta(days=2)
        form.guests.data = 2

    return render_template("book.html", unit=unit, form=form)


def _has_conflict(resource, start, end, time_slot):
    """Return True if the resource is already booked for the requested window."""
    existing = Reservation.query.filter(
        Reservation.resource_id == resource.id,
        Reservation.status.in_(["pending", "confirmed"]),
    ).all()
    for r in existing:
        if r.end_date and end:  # hotel range overlap
            if start < r.end_date and r.start_date < end:
                return True
        else:  # restaurant same date + time
            if r.start_date == start and (r.time_slot == time_slot):
                return True
    return False


@main_bp.route("/unit/<int:unit_id>/review", methods=["POST"])
@login_required
def add_review(unit_id):
    unit = Unit.query.get_or_404(unit_id)
    form = ReviewForm()
    if form.validate_on_submit():
        completed = Reservation.query.filter_by(
            user_id=current_user.id, unit_id=unit.id).filter(
            Reservation.status.in_(["completed", "confirmed"])).first()
        if not completed:
            flash("You can only review places you've booked.", "warning")
            return redirect(url_for("main.unit_detail", unit_id=unit_id))
        if Review.query.filter_by(user_id=current_user.id, unit_id=unit.id).first():
            flash("You've already reviewed this place.", "info")
            return redirect(url_for("main.unit_detail", unit_id=unit_id))

        label, score = ai_engine.analyze_sentiment(form.comment.data)
        review = Review(
            rating=int(form.rating.data), comment=form.comment.data,
            sentiment=label, sentiment_score=score,
            user_id=current_user.id, unit_id=unit.id,
        )
        db.session.add(review)
        notify(unit.manager_id, f"New {form.rating.data}★ review on {unit.name}",
               url_for("main.unit_detail", unit_id=unit.id), icon="star")
        db.session.commit()
        flash("Thanks for your review!", "success")
    else:
        flash("Could not post review. Please check your input.", "danger")
    return redirect(url_for("main.unit_detail", unit_id=unit_id))


@main_bp.route("/favorite/<int:unit_id>", methods=["POST"])
@login_required
def toggle_favorite(unit_id):
    unit = Unit.query.get_or_404(unit_id)
    fav = Favorite.query.filter_by(user_id=current_user.id, unit_id=unit.id).first()
    if fav:
        db.session.delete(fav)
        db.session.commit()
        flash(f"Removed {unit.name} from saved.", "info")
    else:
        db.session.add(Favorite(user_id=current_user.id, unit_id=unit.id))
        db.session.commit()
        flash(f"Saved {unit.name}!", "success")
    return redirect(request.referrer or url_for("main.unit_detail", unit_id=unit_id))


@main_bp.route("/concierge")
def concierge():
    return render_template("concierge.html")
