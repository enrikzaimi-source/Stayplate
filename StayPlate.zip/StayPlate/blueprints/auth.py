"""Authentication routes: register, login, logout."""
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from extensions import db
from models import User
from forms import RegisterForm, LoginForm

auth_bp = Blueprint("auth", __name__)


def _dashboard_for(user):
    if user.is_admin:
        return url_for("admin.dashboard")
    if user.is_manager:
        return url_for("manager.dashboard")
    return url_for("user.dashboard")


@auth_bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(_dashboard_for(current_user))
    form = RegisterForm()
    if form.validate_on_submit():
        if User.query.filter_by(email=form.email.data.lower()).first():
            flash("That email is already registered.", "danger")
            return render_template("auth/register.html", form=form)
        user = User(
            full_name=form.full_name.data.strip(),
            email=form.email.data.lower().strip(),
            phone=form.phone.data,
            role="manager" if form.role.data == "manager" else "user",
        )
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        login_user(user)
        flash(f"Welcome aboard, {user.full_name.split()[0]}!", "success")
        return redirect(_dashboard_for(user))
    return render_template("auth/register.html", form=form)


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(_dashboard_for(current_user))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data.lower().strip()).first()
        if user and user.check_password(form.password.data):
            if not user.is_active:
                flash("This account has been suspended.", "danger")
                return render_template("auth/login.html", form=form)
            login_user(user, remember=form.remember.data)
            flash(f"Welcome back, {user.full_name.split()[0]}!", "success")
            nxt = request.args.get("next")
            return redirect(nxt or _dashboard_for(user))
        flash("Invalid email or password.", "danger")
    return render_template("auth/login.html", form=form)


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You've been signed out.", "info")
    return redirect(url_for("main.index"))
