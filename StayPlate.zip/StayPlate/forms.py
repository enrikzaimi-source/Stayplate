"""WTForms definitions with server-side validation."""
from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import (
    StringField, PasswordField, SelectField, TextAreaField, IntegerField,
    FloatField, DateField, BooleanField, SubmitField, SelectMultipleField,
)
from wtforms.validators import (
    DataRequired, Email, Length, EqualTo, NumberRange, Optional, ValidationError,
)


class RegisterForm(FlaskForm):
    full_name = StringField("Full name", validators=[DataRequired(), Length(2, 120)])
    email = StringField("Email", validators=[DataRequired(), Email(), Length(max=120)])
    phone = StringField("Phone", validators=[Optional(), Length(max=30)])
    password = PasswordField("Password", validators=[DataRequired(), Length(min=6, max=128)])
    confirm = PasswordField(
        "Confirm password",
        validators=[DataRequired(), EqualTo("password", message="Passwords must match.")],
    )
    role = SelectField(
        "I want to",
        choices=[("user", "Book stays & tables (Customer)"),
                 ("manager", "List my establishment (Manager)")],
        default="user",
    )
    submit = SubmitField("Create account")


class LoginForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email()])
    password = PasswordField("Password", validators=[DataRequired()])
    remember = BooleanField("Remember me")
    submit = SubmitField("Sign in")


class ProfileForm(FlaskForm):
    full_name = StringField("Full name", validators=[DataRequired(), Length(2, 120)])
    phone = StringField("Phone", validators=[Optional(), Length(max=30)])
    preferences = StringField("Preferences (comma separated)", validators=[Optional(), Length(max=255)])
    avatar = FileField("Avatar", validators=[FileAllowed(["jpg", "jpeg", "png", "webp"], "Images only.")])
    submit = SubmitField("Save changes")


class PasswordForm(FlaskForm):
    current = PasswordField("Current password", validators=[DataRequired()])
    new = PasswordField("New password", validators=[DataRequired(), Length(min=6, max=128)])
    confirm = PasswordField("Confirm", validators=[DataRequired(), EqualTo("new", "Passwords must match.")])
    submit = SubmitField("Update password")


class UnitForm(FlaskForm):
    name = StringField("Name", validators=[DataRequired(), Length(2, 140)])
    type = SelectField("Type", choices=[("hotel", "Hotel"), ("restaurant", "Restaurant")])
    description = TextAreaField("Description", validators=[Optional(), Length(max=2000)])
    city = StringField("City", validators=[DataRequired(), Length(max=80)])
    address = StringField("Address", validators=[Optional(), Length(max=200)])
    base_price = FloatField("Base price", validators=[DataRequired(), NumberRange(min=0)])
    capacity = IntegerField("Default capacity", validators=[DataRequired(), NumberRange(min=1, max=50)])
    cuisine = StringField("Cuisine (restaurants)", validators=[Optional(), Length(max=80)])
    star_rating = SelectField(
        "Star rating (hotels)",
        choices=[(str(i), f"{i} star") for i in range(1, 6)],
        default="3",
    )
    amenities = SelectMultipleField("Amenities", coerce=int)
    image = FileField("Cover image", validators=[FileAllowed(["jpg", "jpeg", "png", "webp"], "Images only.")])
    submit = SubmitField("Save establishment")


class ResourceForm(FlaskForm):
    name = StringField("Name", validators=[DataRequired(), Length(2, 80)])
    capacity = IntegerField("Capacity", validators=[DataRequired(), NumberRange(min=1, max=50)])
    price = FloatField("Price", validators=[DataRequired(), NumberRange(min=0)])
    description = StringField("Description", validators=[Optional(), Length(max=255)])
    is_active = BooleanField("Active", default=True)
    submit = SubmitField("Save")


class ReservationForm(FlaskForm):
    resource_id = SelectField("Choose", coerce=int, validators=[DataRequired()])
    start_date = DateField("Date", validators=[DataRequired()])
    end_date = DateField("Check-out", validators=[Optional()])
    time_slot = SelectField(
        "Time",
        choices=[(t, t) for t in ["12:00", "12:30", "13:00", "13:30", "18:00",
                                   "18:30", "19:00", "19:30", "20:00", "20:30", "21:00"]],
        validators=[Optional()],
    )
    guests = IntegerField("Guests", validators=[DataRequired(), NumberRange(min=1, max=50)])
    special_requests = TextAreaField("Special requests", validators=[Optional(), Length(max=500)])
    submit = SubmitField("Confirm reservation")


class ReviewForm(FlaskForm):
    rating = SelectField("Rating", choices=[(str(i), f"{i} star") for i in range(5, 0, -1)],
                         default="5", validators=[DataRequired()])
    comment = TextAreaField("Your review", validators=[Optional(), Length(max=1000)])
    submit = SubmitField("Post review")
