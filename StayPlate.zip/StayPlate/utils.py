"""Shared helpers: role decorators, notifications, reservation codes."""
import random
import string
from functools import wraps
from flask import abort
from flask_login import current_user
from extensions import db
from models import Notification


def role_required(*roles):
    """Restrict a view to one or more roles."""
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not current_user.is_authenticated:
                abort(403)
            if current_user.role not in roles:
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator


def gen_code(prefix="RES"):
    """Generate a short unique reservation code."""
    rnd = "".join(random.choices(string.ascii_uppercase + string.digits, k=6))
    return f"{prefix}-{rnd}"


def notify(user_id, message, link=None, icon="bell"):
    """Create an in-app notification."""
    n = Notification(user_id=user_id, message=message, link=link, icon=icon)
    db.session.add(n)
    return n
